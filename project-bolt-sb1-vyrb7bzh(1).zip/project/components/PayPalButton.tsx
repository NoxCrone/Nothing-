import { PayPalButtons, PayPalScriptProvider } from '@paypal/react-paypal-js';
import { Platform, View } from 'react-native';
import { useUpgradeStore } from '../store/useUpgradeStore';

const PAYPAL_CLIENT_ID = 'YOUR_PAYPAL_CLIENT_ID';

export function PayPalButton() {
  const setHasUpgrade = useUpgradeStore((state) => state.setHasUpgrade);

  if (Platform.OS !== 'web') {
    return null;
  }

  return (
    <View style={{ width: 300, marginTop: 20 }}>
      <PayPalScriptProvider options={{ 'client-id': PAYPAL_CLIENT_ID }}>
        <PayPalButtons
          style={{ layout: 'horizontal' }}
          createOrder={(data, actions) => {
            return actions.order.create({
              purchase_units: [
                {
                  amount: {
                    value: '0.99',
                    currency_code: 'EUR',
                  },
                  description: 'Upgrade to Something',
                },
              ],
            });
          }}
          onApprove={async (data, actions) => {
            if (actions.order) {
              const details = await actions.order.capture();
              if (details.status === 'COMPLETED') {
                setHasUpgrade(true);
              }
            }
          }}
        />
      </PayPalScriptProvider>
    </View>
  );
}