import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { PayPalButton } from '../../components/PayPalButton';
import { useUpgradeStore } from '../../store/useUpgradeStore';

export default function NothingScreen() {
  const hasUpgrade = useUpgradeStore((state) => state.hasUpgrade);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.contentContainer}>
        <Text style={styles.nothingText}>{hasUpgrade ? 'Something' : 'nothing'}</Text>
        <PayPalButton />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  nothingText: {
    fontSize: 24,
    fontWeight: '300',
    color: '#000000',
    letterSpacing: 0.5,
  },
});