import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UpgradeState {
  hasUpgrade: boolean;
  setHasUpgrade: (value: boolean) => void;
}

export const useUpgradeStore = create<UpgradeState>()(
  persist(
    (set) => ({
      hasUpgrade: false,
      setHasUpgrade: (value) => set({ hasUpgrade: value }),
    }),
    {
      name: 'upgrade-storage',
    }
  )
);